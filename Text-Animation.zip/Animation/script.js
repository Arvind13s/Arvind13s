// Initialize Typed.js for dynamic typing animation
const typed = new Typed('#typed-text', {
    strings: [
      "Hi, I'm [Name]",
    ],
    typeSpeed: 50,        // Typing speed (ms per character)
    backSpeed: 30,        // Backspacing speed
    backDelay: 1000,      // Delay before backspacing
    startDelay: 500,      // Delay before typing starts
    loop: true,           // Loop the animation
    showCursor: true,     // Show the blinking cursor
    cursorChar: '|',      // Customize cursor character
    smartBackspace: true  // Only backspace what's needed
  });
  